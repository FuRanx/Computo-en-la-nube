import 'package:flutter/material.dart';
import 'package:practica_02/src/app.dart';

void main() {
  runApp(MyApp());
}
